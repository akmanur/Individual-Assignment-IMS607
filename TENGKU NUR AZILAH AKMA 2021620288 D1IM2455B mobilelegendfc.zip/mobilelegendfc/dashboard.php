<!-- dashboard.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Welcome to the Admin Dashboard</h1>
    <ul>
        <li><a href="admin_view_messages.php">View Messages</a></li>
        <!-- Add more links/buttons for additional functionalities -->
    </ul>
</body>
</html>
