<?php
include('db_connection.php');

// Retrieve data from the committee table
$result = $conn->query("SELECT * FROM committee");

// Process and display the data
while ($row = $result->fetch_assoc()) {
    echo "Name: " . $row["name"] . "<br>";
    echo "Position: " . $row["position"] . "<br>";
    echo "Bio: " . $row["bio"] . "<br><br>";
}

// Close the database connection
$conn->close();
?>
