<?php
// Use __DIR__ to get the absolute path of the current directory
include(__DIR__ . '/db_connection.php');

// Check if the connection was successful
if ($conn === null) {
    die("Connection failed: Unable to include db_connection.php");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["Name"];
    $email = $_POST["Email"];
    $message = $_POST["Message"];

    // Insert data into the contact_submissions table
    $sql = "INSERT INTO contact_submissions (name, email, message) VALUES ('$name', '$email', '$message')";

    if ($conn->query($sql) === TRUE) {
        echo "Submission successful!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
<?php
// Use __DIR__ to get the absolute path of the current directory
include(__DIR__ . '/db_connection.php');

// Check if the connection was successful
if ($conn === null) {
    die("Connection failed: Unable to include db_connection.php");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["Name"];
    $email = $_POST["Email"];
    $message = $_POST["Message"];

    // Insert data into the contact_submissions table
    $sql = "INSERT INTO contact_submissions (name, email, message) VALUES ('$name', '$email', '$message')";

    if ($conn->query($sql) === TRUE) {
        echo "Submission successful!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
