<!DOCTYPE html>
<html lang="en">
<head>
<title>MOBILE LEGEND FAN CLUB MALAYSIA</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
<style>
body,h1,h2,h3,h4,h5 {font-family: "Poppins", sans-serif}
body {font-size:16px;}
.w3-half img{margin-bottom:-6px;margin-top:16px;opacity:0.8;cursor:pointer}
.w3-half img:hover{opacity:1}
</style>
</head>
<body>

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-purple w3-collapse w3-top w3-large w3-padding" style="z-index:3;width:300px;font-weight:bold;" id="mySidebar"><br>
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-button w3-hide-large w3-display-topleft" style="width:100%;font-size:22px">Close Menu</a>
  <div class="w3-container">
    <h3 class="w3-padding-64"><b>Mobile Legend Fan<br>Awakened!</b></h3>
  </div>
  <div class="w3-bar-block">
    <a href="#" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Home</a> 
    <a href="#showcase" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Showcase</a> 
    <a href="#Membership" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Membership</a> 
    <a href="#Activities" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Activities</a> 
    <a href="#Club" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Club</a> 
    <a href="#Contact Us" onclick="w3_close()" class="w3-bar-item w3-button w3-hover-white">Contact Us</a>
  </div>
</nav>

<!-- Top menu on small screens -->
<header class="w3-container w3-top w3-hide-large w3-purple w3-xlarge w3-padding">
  <a href="javascript:void(0)" class="w3-button w3-purple w3-margin-right" onclick="w3_open()">☰</a>
  <span>Mobile Legend FC, Malaysia</span>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:340px;margin-right:40px">

  <!-- Header -->

  <div class="w3-container" style="margin-top:80px" id="showcase">
    <p align="right"><a href="crud/crud/index.php">Login to Admin</a>
    <h1 class="w3-jumbo"><b>WELCOME TO MOBILE LEGEND MALAYSIA FAN CLUB</b></h1>
    <h1 class="w3-xxxlarge w3-text-purple"><b>Showcase.</b></h1>
    <hr style="width:50px;border:5px solid pink" class="w3-round">
    <center><iframe width="854" height="480" src="https://www.youtube.com/embed/eMkzqWPmOwU"></iframe></center>
</p></div>

  
  
  <!-- Club grid (modal) -->
  <div class="w3-row-padding">
    <div class="w3-half">
      <img src="miya.jpg" style="width:100%" onclick="onClick(this)" alt="Miya">
      <img src="gusion.jpg" style="width:100%" onclick="onClick(this)" alt="Gusion">
      <img src="nana.jpg" style="width:100%" onclick="onClick(this)" alt="Nana">
    </div>

    <div class="w3-half">
      <img src="johnson.jpg" style="width:100%" onclick="onClick(this)" alt="Johnson">
      <img src="gatotkaca.jpg" style="width:100%" onclick="onClick(this)" alt="Gatotkaca">
      <img src="luoyi.jpg" style="width:100%" onclick="onClick(this)" alt="Luo Yi">
    </div>
  </div>

  <!-- Modal for full size images on click-->
  <div id="modal01" class="w3-modal w3-black" style="padding-top:0" onclick="this.style.display='none'">
    <span class="w3-button w3-black w3-xxlarge w3-display-topright">×</span>
    <div class="w3-modal-content w3-animate-zoom w3-center w3-transparent w3-padding-64">
      <img id="img01" class="w3-image">
      <p id="caption"></p>
    </div>
  </div>


  <!-- Membership -->
  <div class="w3-container" id="Membership" style="margin-top:75px">
    <h1 class="w3-xxxlarge w3-text-purple"><b>Membership.</b></h1>
    <hr style="width:50px;border:5px solid pink" class="w3-round">
   
    <div class="container mt-5">
        <h3>Membership form for Mobile Legend Malaysia Fan Club System</h3>
        <form action="membersubmission.php" method="post">
            <!-- Your form fields go here -->
            <div class="mb-3">
                <label for="first_name" class="form-label">First Name:</label>
                <input type="text" class="form-control" id="first_name" name="first_name" required>
            </div>
<br>
            <div class="mb-3">
                <label for="last_name" class="form-label">Last Name:</label>
                <input type="text" class="form-control" id="last_name" name="last_name" required>
            </div>
<br>
            <div class="mb-3">
                <label for="email" class="form-label">Email:</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <br>
<div><label for="password">Password:</label>
<input type="password" name="password" id="password" required></div>
<br>
            <div class="mb-3">
                <label for="gender" class="form-label">Gender:</label>
                <select class="form-select" id="gender" name="gender" required>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <!-- Add other gender options as needed -->
                </select>
            </div>
<br>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</body>

    </div>
  </div>
  
  <!-- Activities -->
  <div class="w3-container" id="Activities" style="margin-top:75px">
    <h1 class="w3-xxxlarge w3-text-purple"><b>Activities.</b></h1>
    <hr style="width:50px;border:5px solid pink" class="w3-round">
    <p>We prepared various activities for all the players of Mobile Legend in Malaysia.</p>
    <p class="justified-text">Embark on a thrilling journey into the heart of Mobile Legends with our exclusive Fan Club, where the excitement never ceases, and the battles are always on the verge of legendary. As a member, you'll find yourself immersed in an adrenaline-fueled world where strategy and camaraderie collide to create an unparalleled gaming experience. Join forces with like-minded warriors, all sharing a passion for the art of strategy and the thrill of victory. This is not just a fan club; it's a community that lives, breathes, and dominates the virtual battlefield together. Whether you're a seasoned player or a newcomer eager to learn the ropes, our Fan Club is the ultimate haven for Mobile Legends aficionados. It's a place where every match is an opportunity to showcase your skills, learn from others, and celebrate the highs and lows of the gaming journey. Unleash your inner hero and become part of a community that understands the language of Mobile Legends, where every triumph is a collective achievement, and every defeat is a lesson learned. Elevate your gaming experience, stand shoulder to shoulder with champions, and revel in the unparalleled joy that comes with being part of our Mobile Legends Fan Club. Are you ready to join the ranks of the elite and make your mark on the virtual battlegrounds? The adventure awaits!
    </p>
    <p><b>Our Activities are thoughtfully chosen</b>:</p>
  </div>

  <!-- The Team -->
  <div class="w3-row-padding w3-grayscale">
    <div class="w3-col m4 w3-margin-bottom">
      <div class="w3-light-grey">
        <img src="m1.png" alt="John" style="width:100%">
        <div class="w3-container">
          <h3>2024</h3>
          <p class="w3-opacity">MID SEASON CUP</p>
          <p>We are excited to be part of this year Mid Season Cup</p>
        </div>
      </div>
    </div>
    <div class="w3-col m4 w3-margin-bottom">
      <div class="w3-light-grey">
        <img src="m2.jpg" alt="Jane" style="width:100%">
        <div class="w3-container">
          <h3>2024</h3>
          <p class="w3-opacity">MALAYSIA IS CHOSEN</p>
          <p>This year is going to be rock! We are the MVP!!</p>
        </div>
      </div>
    </div>
    <div class="w3-col m4 w3-margin-bottom">
      <div class="w3-light-grey">
        <img src="m3.jpg" alt="Mike" style="width:100%">
        <div class="w3-container">
          <h3>2024</h3>
          <p class="w3-opacity">M6 WORLD CHAMPIONSHIP</p>
          <p>Gear up your skills! Gonna get those triple kill!!! Savage!!!</p>
        </div>
      </div>
    </div>
  </div>

  <!-- Club -->
  <div class="w3-container" id="Club" style="margin-top:75px">
    <h1 class="w3-xxxlarge w3-text-purple"><b>Club.</b></h1>
    <hr style="width:50px;border:5px solid pink" class="w3-round">
    </div>
  <div class="container">
  <img src="banner.png" alt="Girl in a jacket"><br>
  <p class="justified-text">"Calling all Mobile Legends enthusiasts! Elevate your gaming experience by joining our Collaboration Club – a haven for fans who appreciate skill, strategy, and the joy of teamwork. Together, we'll embark on epic journeys, share tips, and celebrate victories. Join us in creating a vibrant community where Mobile Legends lovers unite, forging alliances that go beyond the virtual realm. Step into a world where collaboration is key, and the thrill of victory is amplified when shared with like-minded gamers. For further information and to join our exciting club, stay tuned for updates on our social media channels and official website. Join our club and let's embark on a legendary adventure together!"</p>
<style>
    .justified-text {
      text-align: justify;
    }
  </style>
    
  <!-- Contact Us -->
<div class="w3-container" id="Contact Us" style="margin-top:75px">
    <h1 class="w3-xxxlarge w3-text-purple"><b>Contact Us.</b></h1>
    <hr style="width:50px;border:5px solid pink" class="w3-round">
    <p>Please leave your thoughtful experience with us :) We love to read people's messages!</p>
    <form action="contactsubmission.php" method="post" target="_blank">
        <div class="w3-section">
            <label>Name</label>
            <input class="w3-input w3-border" type="text" name="Name" required>
        </div>
        <div class="w3-section">
            <label>Email</label>
            <input class="w3-input w3-border" type="text" name="Email" required>
        </div>
        <div class="w3-section">
            <label>Message</label>
            <textarea class="w3-input w3-border" name="Message" required></textarea>
        </div>
        <button type="submit" class="w3-button w3-block w3-padding-large w3-purple w3-margin-bottom">Send Message</button>
    </form>
</div>



<!-- End page content -->
</div>

<!-- W3.CSS Container -->
<div class="w3-light-grey w3-container w3-padding-32" style="margin-top:75px;padding-right:58px"><p class="w3-right">Mobile Legend Fan Club <a href="https://www.w3schools.com/w3css/default.asp" title="W3.CSS" target="_blank" class="w3-hover-opacity">w3.css</a></p></div>

<script>
// Script to open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("myOverlay").style.display = "block";
}
 
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("myOverlay").style.display = "none";
}

// Modal Image Gallery
function onClick(element) {
  document.getElementById("img01").src = element.src;
  document.getElementById("modal01").style.display = "block";
  var captionText = document.getElementById("caption");
  captionText.innerHTML = element.alt;
}
</script>

</body>
</html>
