<?php
// Use __DIR__ to get the absolute path of the current directory
include(__DIR__ . '/db_connection.php');

// Check if the connection was successful
if ($conn === null) {
    die("Connection failed: Unable to include db_connection.php");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST["Name"]);
    $email = mysqli_real_escape_string($conn, $_POST["Email"]);
    $message = mysqli_real_escape_string($conn, $_POST["Message"]);

    // Insert data into the contact_messages table
    $sql = "INSERT INTO contact_messages (contact_name, contact_email, contact_desc) VALUES ('$name', '$email', '$message')";

    if ($conn->query($sql) === TRUE) {
        // Redirect back to the Contact Us page with a success message
        header("Location: index.php?msg=Message submitted successfully");
        exit();
    } else {
        // Redirect back to the Contact Us page with an error message
        header("Location: index.php?msg=Failed to submit message. Please try again later.");
        exit();
    }
}

// Close the database connection
$conn->close();

// After executing the query, check for errors
if ($conn->query($sql) === TRUE) {
    // Your existing code for successful insertion
} else {
    // Display the SQL error
    echo "Error: " . $sql . "<br>" . $conn->error;
    // or log the error to a file for later analysis
}






?>
