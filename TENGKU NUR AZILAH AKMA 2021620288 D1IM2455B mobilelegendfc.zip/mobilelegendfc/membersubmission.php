<!-- membersubmission -->
<?php
include "db_conn.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $first_name = $_POST["first_name"];
    $last_name = $_POST["last_name"];
    $email = $_POST["email"];
    $gender = $_POST["gender"];

    // Insert data into the database
    $sql = "INSERT INTO members (first_name, last_name, email, gender) VALUES ('$first_name', '$last_name', '$email', '$gender')";
    mysqli_query($conn, $sql);

    // Redirect back to the index page with a success message
    header("Location: index.php?msg=Form submitted successfully");
    exit();
}
?>
