<?php
include "db_conn.php";

if (isset($_POST["submit"])) {
    $contact_name = $_POST['contact_name'];
    $contact_email = $_POST['contact_email'];
    $contact_desc = $_POST['contact_desc'];

    $sql = "INSERT INTO `contact_messages` (`contact_name`, `contact_email`, `contact_desc`) VALUES ('$contact_name', '$contact_email', '$contact_desc')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        header("Location: contact.php?msg=New contact added successfully");
        exit();
    } else {
        echo "Failed: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Include necessary head content such as title, stylesheets, etc. -->
</head>

<body>
    <!-- Include necessary body content -->
    <form action="" method="post">
        <label>Contact Name:</label>
        <input type="text" name="contact_name" required>
        
        <label>Contact Email:</label>
        <input type="email" name="contact_email" required>

        <label>Contact Description:</label>
        <textarea name="contact_desc" required></textarea>

        <button type="submit" name="submit">Add Contact</button>
    </form>
</body>

</html>
