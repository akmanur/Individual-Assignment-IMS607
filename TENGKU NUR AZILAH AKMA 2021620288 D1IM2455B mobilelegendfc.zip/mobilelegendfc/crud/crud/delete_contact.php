<?php
include "db_conn.php";

if (isset($_GET["message_id"])) {
    $message_id = $_GET["message_id"];

    // Delete contact based on message_id
    $sql = "DELETE FROM `contact_messages` WHERE `message_id` = $message_id";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        header("Location: contact.php?msg=Contact deleted successfully");
        exit();
    } else {
        echo "Failed: " . mysqli_error($conn);
    }
} else {
    echo "Invalid request.";
    exit();
}
?>
