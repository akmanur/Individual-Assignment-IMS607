<?php
include "db_conn.php";

$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$email = $_POST['email'];
$gender = $_POST['gender'];
$username = $_POST['username'];
$password = isset($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : '';

// Add the 'password' field to your INSERT query
$sql = "INSERT INTO members (first_name, last_name, email, gender, username, password) VALUES ('$first_name', '$last_name', '$email', '$gender', '$username', '$password')";

if (mysqli_query($conn, $sql)) {
    header("Location: index.php?msg=Registration successful");
    exit();
} else {
    header("Location: index.php?msg=Error in registration");
    exit();
}

mysqli_close($conn);
?>
