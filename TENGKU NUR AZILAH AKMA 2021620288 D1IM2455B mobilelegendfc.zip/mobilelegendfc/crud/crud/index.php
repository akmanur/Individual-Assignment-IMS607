<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="container">
        <form action="login2.php" method="post">
            <h2>Login</h2>
            <label for="username">Username:</label>
            <input type="text" name="username" required>

            <label for="password">Password:</label>
            <input type="password" name="password" required>

            <button type="submit">Login</button>
        </form>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home Page</title>
  <style>
    body {
      margin: 0;
      padding: 0;
    }

    .button-container {
      position: absolute;
      top: 10px; /* Adjust the top position as needed */
      right: 10px; /* Adjust the right position as needed */
    }

    .button-container button {
      /* Add additional styles for your button if needed */
    }
  </style>
</head>
<body>

  <!-- Your existing HTML content -->

  <div class="button-container">
    <button type="button" onclick="redirectToOtherWebsite()">Main Website</button>
  </div>

  <script>
    function redirectToOtherWebsite() {
      // Replace 'https://example.com' with the actual URL of the external website
      window.location.href = 'http://localhost/mobilelegendfc/';
    }
  </script>

</body>
</html>


</body>
</html>


    </div>

</body>
</html>