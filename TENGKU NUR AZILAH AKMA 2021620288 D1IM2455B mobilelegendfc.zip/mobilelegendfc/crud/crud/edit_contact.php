<?php
include "db_conn.php";

if (isset($_GET["message_id"])) {
    $message_id = $_GET["message_id"];

    // Fetch contact details based on message_id
    $sql = "SELECT * FROM `contact_messages` WHERE `message_id` = $message_id";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    if (!$row) {
        echo "Contact not found.";
        exit();
    }
} else {
    echo "Invalid request.";
    exit();
}

if (isset($_POST["submit"])) {
    // Update contact details
    $contact_name = $_POST['contact_name'];
    $contact_email = $_POST['contact_email'];
    $contact_desc = $_POST['contact_desc'];

    $sql = "UPDATE `contact_messages` SET `contact_name`='$contact_name', `contact_email`='$contact_email', `contact_desc`='$contact_desc' WHERE `message_id` = $message_id";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        header("Location: contact.php?msg=Contact updated successfully");
        exit();
    } else {
        echo "Failed: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Include necessary head content such as title, stylesheets, etc. -->
</head>

<body>
    <!-- Include necessary body content -->
    <form action="" method="post">
        <label>Contact Name:</label>
        <input type="text" name="contact_name" value="<?php echo $row['contact_name']; ?>" required>
        
        <label>Contact Email:</label>
        <input type="email" name="contact_email" value="<?php echo $row['contact_email']; ?>" required>

        <label>Contact Description:</label>
        <textarea name="contact_desc" required><?php echo $row['contact_desc']; ?></textarea>

        <button type="submit" name="submit">Update Contact</button>
    </form>
</body>

</html>
